//ini import klo pakai const
// import { apikey } from "./util";

//ini import kalau pakai default
// import hey from "./util";
// import { apikey1, apikey2 } from "./util";
// import { apikey1, apikey2 as api2 } from "./util";
// import * as util from "./util.js";

// console.log(hey, util.apikey1, util.apikey2);

// NEW

// let userMessage = "Hello World";
// console.log(userMessage);

// function greet(userName, message) {
//   return "Hi, " + userName + " " + message;
// }

// const wahdaa = greet("wahda", "good morning");
// console.log(wahdaa);
// const galihh = greet("galih", "good morning");
// console.log(galihh);

// NEW

// export default (userName, message) => {
//   console.log("Hi, " + userName + " " + message);
//   return "Hi, " + userName + " " + message;
// };

// NEW

// const user = {
//   name: "Wahda",
//   age: 18,
//   greet() {
//     console.log("hello", this.name);
//   },
// };

// console.log(user, user.name);
// user.greet();

// class User {
//   constructor(name, age) {
//     this.name = name;
//     this.age = age;
//   }
//   greet() {
//     console.log("Hi!");
//   }
// }

// const user1 = new User("Aldy", 19);
// console.log(user1);
// user1.greet();

// NEW

const hobbies = ["singing", "cooking", "painting"];
console.log(hobbies[0]);

hobbies.push("jogging");
console.log(hobbies[3]);

const index = hobbies.findIndex((item) => item === "painting");
console.log(index);

hobbies.map((item) => console.log(item + "!"));

const editedHobbies = hobbies.map((item) => ({ text: item }));
console.log(editedHobbies);
