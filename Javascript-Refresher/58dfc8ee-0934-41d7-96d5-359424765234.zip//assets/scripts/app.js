//ini import klo pakai const
// import { apikey } from "./util";

//ini import kalau pakai default
// import hey from "./util";
// import { apikey1, apikey2 } from "./util";
// import { apikey1, apikey2 as api2 } from "./util";
// import * as util from "./util.js";

// console.log(hey, util.apikey1, util.apikey2);

// NEW

// let userMessage = "Hello World";
// console.log(userMessage);

// function greet(userName, message) {
//   return "Hi, " + userName + " " + message;
// }

// const wahdaa = greet("wahda", "good morning");
// console.log(wahdaa);
// const galihh = greet("galih", "good morning");
// console.log(galihh);

// NEW

// export default (userName, message) => {
//   console.log("Hi, " + userName + " " + message);
//   return "Hi, " + userName + " " + message;
// };

// NEW

// const user = {
//   name: "Wahda",
//   age: 18,
//   greet() {
//     console.log("hello", this.name);
//   },
// };

// console.log(user, user.name);
// user.greet();

// class User {
//   constructor(name, age) {
//     this.name = name;
//     this.age = age;
//   }
//   greet() {
//     console.log("Hi!");
//   }
// }

// const user1 = new User("Aldy", 19);
// console.log(user1);
// user1.greet();

// NEW

// const hobbies = ["singing", "cooking", "painting"];
// console.log(hobbies[0]);

// hobbies.push("jogging");
// console.log(hobbies[3]);

// const index = hobbies.findIndex((item) => item === "painting");
// console.log(index);

// hobbies.map((item) => console.log(item + "!"));

// const editedHobbies = hobbies.map((item) => ({ text: item }));
// console.log(editedHobbies);

// NEW

// const [firtsName, lastName] = ["Wahda", "Adella"];
// console.log(firtsName, lastName);

// const { name, age } = {
//   name: "Wahda",
//   age: 18,
// };
// console.log(name, age);

// NEW

// const hobbies = ["singging", "dancing", "painting"];
// const user = {
//   name: "Wahda",
//   age: 18,
// };

// const newHobbies = ["breaking"];
// const mergedHobbies = [...hobbies, ...newHobbies];
// console.log(mergedHobbies);

// const extendUser = {
//   isAdmin: true,
//   ...user,
// };
// console.log(extendUser);

// NEW

// const password = "Hello";

// if (password === "Hello") {
//   console.log("owww");
// } else if (password === "hihihi") {
//   console.log("hihihi");
// } else {
//   console.log("hahahahah");
// }

// const hobbies = ["dancing", "singing", "reading"];
// for (const hobby of hobbies) {
//   console.log(hobby);
// }

// NEW

// function handleTimeOut() {
//   console.log("Time Out");
// }

// const handleTimeOut2 = () => {
//   console.log("Time Out Again");
// };

// setTimeout(handleTimeOut, 2000);
// setTimeout(handleTimeOut2, 3000);
// setTimeout(() => {
//   console.log("Time Out Again and Again");
// }, 4000);

// function greeter(greetfn) {
//   greetfn();
// }
// greeter(() => console.log("hi"));

// NEW

// function init() {
//   function greet() {
//     consolo.log("hi!");
//   }

//   greet();
// }

// init();

// NEW

// let userMessage = "Hello!";
// userMessage = userMessage.concat("!!!");

// NEW

const hobbies = ["singing", "dancing"];
hobbies.push("cing");
