//ini contoh pakai var
export let apikey1 = "apikey1";
export let apikey2 = "apikey2";

//ini pakai default, default harus hanya ada satu di file
export default "dcheuyh";
