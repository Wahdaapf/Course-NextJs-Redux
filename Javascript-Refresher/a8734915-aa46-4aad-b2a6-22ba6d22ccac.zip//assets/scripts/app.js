//ini import klo pakai const
// import { apikey } from "./util";

//ini import kalau pakai default
// import hey from "./util";
// import { apikey1, apikey2 } from "./util";
// import { apikey1, apikey2 as api2 } from "./util";
// import * as util from "./util.js";

// console.log(hey, util.apikey1, util.apikey2);

// NEW

let userMessage = "Hello World";
console.log(userMessage);
